This is intended for use with edit-server.el and the corresponding
"Edit with Emacs" extension for the Chromium/Google Chrome Web browser.
See https://github.com/stsquad/emacs_chrome

This provides some simple functions for deHTMLizing and reHTMLizing
"plain text" as encoded by e.g. GMail composition boxes.
