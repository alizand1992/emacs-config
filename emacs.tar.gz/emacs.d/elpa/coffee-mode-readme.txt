Provides syntax highlighting, indentation support, imenu support,
compiling to JavaScript, REPL, a menu bar, and a few cute commands.
