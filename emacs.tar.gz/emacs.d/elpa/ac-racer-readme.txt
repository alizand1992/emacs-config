ac-racer.el provides auto-complete source for Rust programming language.
