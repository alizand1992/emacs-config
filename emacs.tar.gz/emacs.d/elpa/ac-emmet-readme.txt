Provides auto-complete sources for emmet-mode.
